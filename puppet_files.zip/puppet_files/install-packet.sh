###########################
# This script will install dot net and azcopy on linux machine. Also create required packets directories.
# Finally download all required packets mentioned via array passed to this script.
# How to run example
# chmod +x *.sh; sh install-packet.sh "RR-8.0.121866.0.zip PS-2.0.684.8.zip DP-1.0.985.11.zip"
###########################

src=$(cat ./downloadcmrspacket.cfg|grep -i 'src'|cut -d '=' -f2-5)
key=$(cat ./downloadcmrspacket.cfg|grep -i 'key'|cut -d '=' -f2-5)
dest="/packets/cmrslink/Cmrs_Packets"
relname=($1)

red="\e[0;31m"
green="\e[0;32m"
blue="\e[0;34m"
nc='\e[0m'

#Function to Check The Status Of The Excuted Command
status()
{
if [ $? -ne 0 ];then
COMMENTS=$1
sleep 1
echo -e "$COMMENTS"
sleep 1;
else 
COMMENTS=$2
echo -e "$COMMENTS"
fi
}

yum -y install libicu libunwind
chmod +x *.sh
./dotnet-install.sh
cd /var/tmp
if [ -f "azcopy.tar.gz" ]; then
  echo "azcopy file is already present"
else
  wget -O azcopy.tar.gz https://aka.ms/downloadazcopylinux64
  status  "${red}Azcopy download failed" "${blue}Azcopy download successful${green}[OK]"
  tar -xf azcopy.tar.gz
  status  "${red}Azcopy untar failed" "${blue}Azcopy untar successful${green}[OK]"
  sudo ./install.sh
  status  "${red}Azcopy install failed" "${blue}Azcopy install successful${green}[OK]"
fi
for i in ${!relname[@]}; do
name=""
prefix=$(echo ${relname[$i]}|cut -d '-' -f1)
echo "Prefix is $prefix"
release=${relname[$i]}
echo "Release name is  $release"
if [ $prefix == 'PS' ]; then
  echo "Build is PAS"
  name="Pas"
elif [ $prefix == 'DP' ]; then
  echo "Build is DataPublisher"
  name="DataPublisher"
else
  echo "Build is RegReport"
  name="RegReport"
fi
if [ -f $dest/$name/$release ]; then
  echo "$release is already present"
else
  mkdir -p $dest/$name
  status  "${red}create $dest/$name directory failed" "${blue}create $dest/$name directory successful${green}[OK]"
  azcopy --source $src/$name/$release --destination $dest/$name/$release --source-key $key
  status  "${red}Azcopy $src/$name/$release download failed" "${blue}Azcopy $src/$name/$release download successful${green}[OK]"
fi

cd $dest/$name
status  "${red}Change directory $dest/$name failed" "${blue}Change directory $dest/$name successful${green}[OK]"
unzip $release
status  "${red}Unzip $dest/$name/$release failed" "${blue}Unzip $dest/$name/$release successful${green}[OK]"

done
