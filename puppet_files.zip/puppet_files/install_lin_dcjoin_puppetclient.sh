ServerName=$1
DomainName=$2
PuppetServer=$3
PuppetServerIP=$4
ClientName=$5
DomainUserName=$6
DomainUserPassword=$7
ADServerIP=$8
ADServer=$9
Environment=${10}
Role=${11}
red="\e[0;31m"
green="\e[0;32m"
blue="\e[0;34m"
#Function to Check The Status Of The Excuted Command
status()
{
if [ $? -ne 0 ];then
COMMENTS=$1
sleep 1
echo -e "$COMMENTS"
sleep 1;
else 
COMMENTS=$2
echo -e "$COMMENTS"
fi
}

PuppetClientConfFile="/etc/puppetlabs/puppet/puppet.conf"
PuppetServerFqdn=$PuppetServer.$DomainName
ServerNameFqdn=$ServerName.$DomainName
DomainName_Upper=$(echo $DomainName |  tr '[a-z]' '[A-Z]')

echo $PuppetServerIP $PuppetServerFqdn  $PuppetServer  >> /etc/hosts
status  "${red}Hosts entry insertion for Puppet Server failed" "${blue}Hosts entry insertion for Puppet Server sucessfull${green}[OK]"

echo $ADServerIP $ADServerFqdn $ADServer  >> /etc/hosts
status  "${red}Hosts entry insertion for AD Server failed" "${blue}Hosts entry insertion for AD Server sucessfull${green}[OK]"


sed  -i 's/reddog.microsoft.com//g' /etc/resolv.conf
status  "${red}Resolv.conf update failed" "${blue}Resolv.conf update sucessfull${green}[OK]"

if   grep -q -i "release 7" /etc/redhat-release ; then

PuppetClientMsi_EL7="puppet-agent-1.10.5-1.el7.x86_64.rpm"
hostnamectl set-hostname $ServerNameFqdn
systemctl restart systemd-hostnamed
status  "${red}fqdn setup for $HOSTNAME failed on EL7" "${blue}fqdn setup for $HOSTNAME was sucessfull on EL7${green}[OK]"

elif grep -q -i "release 6" /etc/redhat-release ; then
PuppetClientMsi_EL6="puppet-agent-1.10.5-1.el6.x86_64.rpm"
hostname "$ServerNameFqdn"
sed -i "s/HOSTNAME=.*/HOSTNAME=$ServerNameFqdn/g" /etc/sysconfig/network
status  "${red}fqdn setup for $HOSTNAME failed on EL6" "${blue}fqdn setup for $HOSTNAME was sucessfull on EL6${green}[OK]"
fi

if   grep -q -i "release 7" /etc/redhat-release ; then

wget -O /var/tmp/puppet-agent-1.10.5-1.el7.x86_64.rpm https://cmrsdevopscommonstorage.blob.core.windows.net/publicbinaries/Linux/$PuppetClientMsi_EL7
yum localinstall /var/tmp/$PuppetClientMsi_EL7  -y
status  "${red}Puppet Client agent  installation failed on EL7" "${blue}Puppet Client agent  installation sucessfull on EL7${green}[OK]"

elif grep -q -i "release 6" /etc/redhat-release ; then
wget -O /var/tmp/puppet-agent-1.10.5-1.el6.x86_64.rpm https://cmrsdevopscommonstorage.blob.core.windows.net/publicbinaries/Linux/$PuppetClientMsi_EL6
yum localinstall /var/tmp/$PuppetClientMsi_EL6  -y
status  "${red}Puppet Client agent  installation failed on EL6" "${blue}Puppet Client agent  installation sucessfull on EL6${green}[OK]"

fi

yum install ntp -y
status  "${red}Ntp installation failed" "${blue}Ntp installation sucessfull${green}[OK]"


if   grep -q -i "release 7" /etc/redhat-release ; then

systemctl restart  ntpd
status  "${red}ntpd service restart failed on EL7" "${blue}ntpd service restart was sucessfull on EL7${green}[OK]"

systemctl enable ntpd
status  "${red}ntpd service enable failed on EL7" "${blue}ntpd service enable was sucessfull on EL7${green}[OK]"

echo -e "[main]\nserver=$PuppetServerFqdn\nautoflush=true\nenvironment=$Environment\nruninterval=300m" >> $PuppetClientConfFile
status  "${red}Puppet Client config file update failed on EL7" "${blue}Puppet Client config file update sucessfull on EL7${green}[OK]"

systemctl restart puppet.service
status  "${red}Puppet service restart failed on EL7" "${blue}Puppet service restart sucessfull on EL7${green}[OK]"

systemctl enable puppet.service
status  "${red}Puppet service enable failed on EL7" "${blue}Puppet service enable sucessfull on EL7${green}[OK]"

yum install sssd realmd oddjob oddjob-mkhomedir adcli samba-common samba-common-tools krb5-workstation openldap-clients policycoreutils-python -y
status  "${red}Installation of RHEL AD packages failed" "${blue}Installation of RHEL AD packages sucessfull${green}[OK]"

echo $DomainUserPassword | realm join --user=$DomainUserName $DomainName
status  "${red}Adding server to domain failed" "${blue}Adding server to domain sucessfull${green}[OK]"

sed -i 's/use_fully_qualified_names = True/use_fully_qualified_names = False/g' /etc/sssd/sssd.conf
status  "${red}Updaing sssd.conf file failed" "${blue}Updaing sssd.conf file sucessfull${green}[OK]"

systemctl restart sssd
status  "${red}Restarting sssd failed" "${blue}Restarting sssd sucessfull${green}[OK]"

sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config
status  "${red}Updaing sshd_config file failed" "${blue}Updaing sshd_config file sucessfull${green}[OK]"

systemctl restart sshd
status  "${red}Restarting sshd failed" "${blue}Restarting sshd sucessfull${green}[OK]"

echo "%domain\\admins@sapient.net ALL=(ALL)       ALL" >> /etc/sudoers.d/domainusers
status  "${red}Adding domian admin users to sudoers failed" "${blue}Adding domian admin users to sudoers sucessfull${green}[OK]"

elif grep -q -i "release 6" /etc/redhat-release ; then

service  ntpd restart
status  "${red}ntpd service restart failed on EL6" "${blue}ntpd service restart was sucessfull on EL6${green}[OK]"

chkconfig ntpd on
status  "${red}ntpd service enable failed on EL6" "${blue}ntpd service enable was sucessfull on EL6${green}[OK]"

echo -e "[main]\nserver=$PuppetServerFqdn\nautoflush=true\nenvironment=$Environment\nruninterval=525600m" >> $PuppetClientConfFile
status  "${red}Puppet Client config file update failed" "${blue}Puppet Client config file update sucessfull${green}[OK]"

service puppet restart
status  "${red}Puppet service restart failed" "${blue}Puppet service restart sucessfull${green}[OK]"

chkconfig puppet on
status  "${red}Puppet service enable failed" "${blue}Puppet service enable sucessfull${green}[OK]"

yum install sssd authconfig realmd oddjob oddjob-mkhomedir adcli samba-common samba-common-tools krb5-workstation openldap-clients policycoreutils-python -y
status  "${red}Installation of RHEL AD packages failed" "${blue}Installation of RHEL AD packages sucessfull${green}[OK]"

sed  -i 's/reddog.microsoft.com//g' /etc/resolv.conf
status  "${red}Resolv.conf update failed" "${blue}Resolv.conf update sucessfull${green}[OK]"

echo -n $DomainUserPassword | adcli join -U $DomainUserName $DomainName  --stdin-password
status  "${red}Adding Server to domain failed" "${blue}Adding Server to domain sucessfull${green}[OK]"

sed -i "s/EXAMPLE.COM/$DomainName_Upper/g;s/example.com/$DomainName/g" /etc/krb5.conf
status  "${red}Updating krb5.conf with domain information failed" "${blue}Updating krb5.conf sucessfull${green}[OK]"

sed -i "s/kdc = kerberos.example.net/kdc = $DomainServer.$DomainName/g;s/admin_server = kerberos.example.net/admin_server = $DomainServer.$DomainName/g" /etc/krb5.conf
status  "${red}Updating krb5.conf with AD Server information failed" "${blue}Updating krb5.conf with AD Server sucessfull${green}[OK]"

authconfig --enablesssd --enablesssdauth --enablemkhomedir  --update 
status  "${red}Updating authconfig failed" "${blue}Updating authconfig  sucessfull${green}[OK]"

cat << EOF > /etc/sssd/sssd.conf
[sssd]
services = nss, pam, ssh, autofs
config_file_version = 2
domains = $DomainName

[domain/$DomainName]
id_provider = ad
fallback_homedir = /home/%u@%d
EOF

chown root:root /etc/sssd/sssd.conf
status "${red}Changing ownership of sssd.conf  failed" "${blue}Changing ownership of sssd.conf  sucessfull${green}[OK]"

chmod 0600 /etc/sssd/sssd.conf
status "${red}Changing Permission of sssd.conf  failed" "${blue}Changing Permission of sssd.conf  sucessfull${green}[OK]"

sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config
status  "${red}Updaing sshd_config file failed" "${blue}Updaing sshd_config file sucessfull${green}[OK]"

service sshd restart
status  "${red}Restarting sshd failed" "${blue}Restarting sshd sucessfull${green}[OK]"

service sssd restart
status "${red}Serivce sssd restart failed" "${blue}Serivce sssd restart sucessfull${green}[OK]"

chkconfig sssd on
status "${red}enable sssd at startup failed" "${blue}Serivce sssd start sucessfull${green}[OK]"

fi
