#!/bin/bash
##Base Variables
PUPPETCODEREPO=cmrsautocode
PUPPETCONFIGREPO=cmrsautoprodconfig
PACKETREPO=cmrsautorelease
CODEBRANCHNAME=$1
CONFIGBRANCHNAME=$2
red="\e[0;31m"
green="\e[0;32m"
blue="\e[0;34m"
nc='\e[0m'

#Function to Check The Status Of The Excuted Command
status()
{
if [ $? -ne 0 ];then
COMMENTS=$1
sleep 1
echo -e "$COMMENTS"
sleep 1;
else 
COMMENTS=$2
echo -e "$COMMENTS"
fi
}


## Repository: cmrsautocode
sudo mkdir -p /opt/app/cmrs/automation/$PUPPETCODEREPO
status  "${red}make dir /opt/app/cmrs/automation/$PUPPETCODEREPO  failed" "${blue}make dir /opt/app/cmrs/automation/$PUPPETCODEREPO sucessfull${green}[OK]"

source cd /opt/app/cmrs/automation/$PUPPETCODEREPO
status  "${red}cd dir /opt/app/cmrs/automation/$PUPPETCODEREPO  failed" "${blue}cd dir /opt/app/cmrs/automation/$PUPPETCODEREPO sucessfull${green}[OK]"

sudo git init
status  "${red}git initialisation under /opt/app/cmrs/automation/$PUPPETCODEREPO failed" "${blue}git initialisation under /opt/app/cmrs/automation/$PUPPETCODEREPO sucessfull${green}[OK]"

sudo git remote add -f origin https://devadm1n@del.tools.publicis.sapient.com/bitbucket/scm/cmrsenvautomation/$PUPPETCODEREPO.git
status  "${red}git remote add for $PUPPETCODEREPO failed" "${blue}git remote add for $PUPPETCODEREPO sucessfull${green}[OK]"

sudo git config core.sparseCheckout true
status  "${red}git sprase checkout setup for $PUPPETCODEREPO failed" "${blue}git sprase checkout setup for $PUPPETCODEREPO sucessfull${green}[OK]"

sudo echo "puppetcode" >> .git/info/sparse-checkout
status  "${red}git sprase checkout for puppetcode under $PUPPETCODEREPO repo failed" "${blue}}git sprase checkout for puppetcode under $PUPPETCODEREPO repo sucessfull${green}[OK]"

sudo git pull origin $CODEBRANCHNAME
status  "${red}git pull for $PUPPETCODEREPO failed" "${blue}git pull for $PUPPETCODEREPO sucessfull${green}[OK]"

sudo git checkout $CODEBRANCHNAME
status  "${red}git checkout for $PUPPETCODEREPO test01 branch failed" "${blue}git checkout for $PUPPETCODEREPO test01 branch sucessfull${green}[OK]"

## Repository: cmrsautoprodconfig
sudo mkdir -p /opt/app/cmrs/automation/$PUPPETCONFIGREPO
status  "${red}make dir /opt/app/cmrs/automation/$PUPPETCONFIGREPO  failed" "${blue}make dir /opt/app/cmrs/automation/$PUPPETCODEREPO sucessfull${green}[OK]"

source cd /opt/app/cmrs/automation/$PUPPETCONFIGREPO
status  "${red}cd dir /opt/app/cmrs/automation/$PUPPETCONFIGREPO  failed" "${blue}cd dir /opt/app/cmrs/automation/$PUPPETCONFIGREPO sucessfull${green}[OK]"

sudo git init
status  "${red}git initialisation under /opt/app/cmrs/automation/$PUPPETCONFIGREPO failed" "${blue}git initialisation under /opt/app/cmrs/automation/$PUPPETCONFIGREPO sucessfull${green}[OK]"

sudo git remote add -f origin https://devadm1n@del.tools.publicis.sapient.com/bitbucket/scm/cmrsenvautomation/$PUPPETCONFIGREPO.git
status  "${red}git remote add for $PUPPETCONFIGREPO failed" "${blue}git remote add for $PUPPETCONFIGREPO sucessfull${green}[OK]"

sudo git config core.sparseCheckout true
status  "${red}git sprase checkout setup for $PUPPETCONFIGREPO failed" "${blue}git sprase checkout setup for $PUPPETCONFIGREPO sucessfull${green}[OK]"

sudo echo "puppetconfig" >> .git/info/sparse-checkout
status  "${red}git sprase checkout for puppetconfig under $PUPPETCONFIGREPO repo failed" "${blue}}git sprase checkout for puppetconfig under $PUPPETCONFIGREPO repo sucessfull${green}[OK]"

sudo git pull origin $CONFIGBRANCHNAME
status  "${red}git pull for $PUPPETCONFIGREPO failed" "${blue}git pull for $PUPPETCONFIGREPO sucessfull${green}[OK]"

sudo git checkout $CONFIGBRANCHNAME
status  "${red}git checkout for $PUPPETCONFIGREPO test01 branch failed" "${blue}git checkout for $PUPPETCONFIGREPO test01 branch sucessfull${green}[OK]"


## Configure Hiera
sudo rm -rf /etc/puppetlabs/code/environments /etc/puppetlabs/puppet/hiera.yaml
status  "${red}removal of /etc/puppetlabs/code/environments and /etc/puppetlabs/puppet/hiera.yaml failed" "${blue}removal of /etc/puppetlabs/code/environments and /etc/puppetlabs/puppet/hiera.yaml was sucessfull${green}[OK]"

sudo ln -s /opt/app/cmrs/automation/$PUPPETCONFIGREPO/puppetconfig/environments /etc/puppetlabs/code/environments
status  "${red}/etc/puppetlabs/code/environments symlink creation failed" "${blue}/etc/puppetlabs/code/environments symlink creation sucessfull${green}[OK]"

sudo ln -s /opt/app/cmrs/automation/$PUPPETCONFIGREPO/puppetconfig/hiera.yaml /etc/puppetlabs/puppet/hiera.yaml
status  "${red}/etc/puppetlabs/puppet/hiera.yaml symlink creation failed" "${blue}/etc/puppetlabs/puppet/hiera.yaml symlink creation sucessfull${green}[OK]"

sudo /opt/puppetlabs/bin/puppetserver gem install hiera-eyaml
status  "${red}eyaml with puppetserver installation failed" "${blue}eyaml with puppetserver installation sucessfull${green}[OK]"

sudo /opt/puppetlabs/puppet/bin/gem install hiera-eyaml
status  "${red}hiera-eyaml gem with puppet apply installation failed" "${blue}hiera-eyaml gem with puppet apply installation sucessfull${green}[OK]"

source cd /opt/puppetlabs/puppet
status  "${red}cd dir /opt/puppetlabs/puppet  failed" "${blue}cd dir /opt/puppetlabs/puppet sucessfull${green}[OK]"

sudo /opt/puppetlabs/puppet/bin/eyaml createkeys --pkcs7-private-key=/etc/puppetlabs/puppet/keys/private_key.pkcs7.pem --pkcs7-public-key=/etc/puppetlabs/puppet/keys/public_key.pkcs7.pem
status  "${red}hiera-eyaml  key creation failed" "${blue}hiera-eyaml  key creation sucessfull${green}[OK]"

chown -R pe-puppet:pe-puppet /etc/puppetlabs/puppet/keys
status  "${red}change ownership of /etc/puppetlabs/puppet/keys  failed" "${blue}change ownership of /etc/puppetlabs/puppet/keys sucessfull${green}[OK]"

chmod -R 0500 /etc/puppetlabs/puppet/keys/
status  "${red}change mode of /etc/puppetlabs/puppet/keys  failed" "${blue}change mode of /etc/puppetlabs/puppet/keys sucessfull${green}[OK]"

chmod 0400 /etc/puppetlabs/puppet/keys/*.pem
status  "${red}change mode of /etc/puppetlabs/puppet/keys/*.pem  failed" "${blue}change mode of /etc/puppetlabs/puppet/keys/*.pem sucessfull${green}[OK]"

sudo mkdir -p /opt/app/cmrs/automation/access_key
status  "${red}mkdir for access key failed" "${blue}mkdir for access key sucessfull${green}[OK]"

sudo cp /var/tmp/readonly_access_azure.enc /opt/app/cmrs/automation/access_key/
status  "${red}copy access key file failed" "${blue}copy access key file sucessfull${green}[OK]"

sudo chown -R root:root /opt/app/cmrs/automation/access_key
status  "${red}Change ownership of access key file failed" "${blue}Change ownership of access key file sucessfull${green}[OK]"

sudo chmod -R 0600 /opt/app/cmrs/automation/access_key
status  "${red}Change permission of access key file failed" "${blue}Change permission of access key file sucessfull${green}[OK]"
