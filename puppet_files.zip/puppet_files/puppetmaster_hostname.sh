#!/bin/bash
PM_JEN_SERVER=$1
DOMAIN_NAME=$2
CONSOLE_PASSWD_PM_JEN=$3
ENVIRONMENT=$4
red="\e[0;31m"
green="\e[0;32m"
blue="\e[0;34m"
nc='\e[0m'

#Function to Check The Status Of The Excuted Command
status()
{
if [ $? -ne 0 ];then
COMMENTS=$1
sleep 1
echo -e "$COMMENTS"
sleep 1;
else 
COMMENTS=$2
echo -e "$COMMENTS"
fi
}

sed -i "s/CONSOLE_PASSWD_PM_JEN/$CONSOLE_PASSWD_PM_JEN/g;s/PM_JEN_SERVER.DOMAIN_NAME/$PM_JEN_SERVER.$DOMAIN_NAME/g" /var/tmp/pe.conf
status "${red}/var/tmp/pe.conf update failed" "${blue}/var/tmp/pe.conf update sucessful${green}[OK]"
